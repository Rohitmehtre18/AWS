"""
rag_engine.py
=============
Retrieval layer for the AWS Cloud & Log Intelligence Agent.

Responsibilities
----------------
* Chunk documents (markdown-aware for docs, line-aware for logs / configs)
* Embed chunks with a BGE model via HuggingFaceEmbeddings
* Persist / query a Chroma vector store (cosine similarity)
* Expose a small, thread-safe API: ``ingest_text``, ``retrieve``, ``seed_from_dir``

Design notes
------------
* BGE models work best when *queries* get an instruction prefix while *documents*
  do not. We set that through ``query_encode_kwargs``.
* Chunk IDs are deterministic (sha1 of source + content), so re-ingesting the
  same file is idempotent and never creates duplicates.
"""

from __future__ import annotations

import hashlib
import logging
import os
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List, Optional

from langchain_chroma import Chroma
from langchain_core.documents import Document
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_text_splitters import (
    MarkdownHeaderTextSplitter,
    RecursiveCharacterTextSplitter,
)

logger = logging.getLogger("rag_engine")

BGE_QUERY_INSTRUCTION = "Represent this sentence for searching relevant passages: "
SUPPORTED_EXTENSIONS = {".md", ".markdown", ".txt", ".log", ".json", ".yaml", ".yml"}


class RAGError(Exception):
    """Raised for recoverable RAG pipeline problems (bad input, store failure...)."""


@dataclass
class RetrievedChunk:
    """A single retrieved chunk plus its provenance and similarity score."""

    content: str
    source: str
    doc_type: str
    section: str
    score: float


class RAGEngine:
    def __init__(
        self,
        persist_dir: str = "./chroma_db",
        embedding_model: str = "BAAI/bge-small-en-v1.5",
        collection_name: str = "aws_knowledge",
        chunk_size: int = 800,
        chunk_overlap: int = 120,
    ) -> None:
        self.persist_dir = persist_dir
        self.embedding_model = embedding_model
        self._lock = threading.Lock()  # Chroma writes from multiple threads -> serialize

        logger.info("Loading embedding model %s (first run downloads weights)...", embedding_model)
        try:
            self.embeddings = HuggingFaceEmbeddings(
                model_name=embedding_model,
                encode_kwargs={"normalize_embeddings": True},  # for documents
                query_encode_kwargs={                          # for queries
                    "normalize_embeddings": True,
                    "prompt": BGE_QUERY_INSTRUCTION,
                },
            )
            self.store = Chroma(
                collection_name=collection_name,
                embedding_function=self.embeddings,
                persist_directory=persist_dir,
                collection_metadata={"hnsw:space": "cosine"},
            )
        except Exception as exc:  # pragma: no cover - environment specific
            raise RAGError(f"Failed to initialise embeddings / vector store: {exc}") from exc

        # Splitters -----------------------------------------------------------
        self._md_header_splitter = MarkdownHeaderTextSplitter(
            headers_to_split_on=[("#", "h1"), ("##", "h2"), ("###", "h3")],
            strip_headers=False,
        )
        self._text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            separators=["\n\n", "\n", ". ", " ", ""],
        )

    # ------------------------------------------------------------------ chunking
    def _chunk(self, text: str, source: str, doc_type: str) -> List[Document]:
        """Split text into Documents carrying useful metadata."""
        base_meta = {"source": source, "doc_type": doc_type}

        if doc_type == "markdown":
            sections = self._md_header_splitter.split_text(text)
            docs = self._text_splitter.split_documents(sections)
            for d in docs:
                d.metadata.update(base_meta)
                d.metadata["section"] = " > ".join(
                    d.metadata.get(h, "") for h in ("h1", "h2", "h3") if d.metadata.get(h)
                )
            return docs

        # logs / configs / plain text: split on lines so stack traces stay together
        chunks = self._text_splitter.split_text(text)
        return [
            Document(page_content=c, metadata={**base_meta, "section": f"part {i + 1}"})
            for i, c in enumerate(chunks)
        ]

    @staticmethod
    def guess_doc_type(filename: str) -> str:
        ext = Path(filename).suffix.lower()
        if ext in {".md", ".markdown"}:
            return "markdown"
        if ext == ".log":
            return "log"
        if ext in {".json", ".yaml", ".yml"}:
            return "config"
        return "text"

    # ------------------------------------------------------------------ ingest
    def ingest_text(self, text: str, source: str, doc_type: Optional[str] = None) -> int:
        """Chunk, embed and store ``text``. Returns number of chunks stored."""
        if not text or not text.strip():
            raise RAGError(f"'{source}' is empty.")
        doc_type = doc_type or self.guess_doc_type(source)

        docs = self._chunk(text, source, doc_type)
        docs = [d for d in docs if d.page_content.strip()]
        if not docs:
            raise RAGError(f"'{source}' produced no chunks.")

        ids = [
            hashlib.sha1(f"{source}|{d.page_content}".encode("utf-8")).hexdigest() for d in docs
        ]
        try:
            with self._lock:
                self.store.add_documents(docs, ids=ids)  # same id => upsert-like, no duplicates
        except Exception as exc:
            raise RAGError(f"Vector store write failed for '{source}': {exc}") from exc

        logger.info("Ingested %d chunks from %s (%s)", len(docs), source, doc_type)
        return len(docs)

    def seed_from_dir(self, directory: str) -> int:
        """Ingest every supported file in ``directory``. Used on first startup."""
        path = Path(directory)
        if not path.is_dir():
            logger.warning("Seed directory %s not found, skipping.", directory)
            return 0
        total = 0
        for f in sorted(path.iterdir()):
            if f.suffix.lower() in SUPPORTED_EXTENSIONS and f.is_file():
                try:
                    total += self.ingest_text(f.read_text(encoding="utf-8", errors="ignore"), f.name)
                except RAGError as exc:
                    logger.warning("Skipping %s: %s", f.name, exc)
        return total

    # ------------------------------------------------------------------ retrieve
    def retrieve(
        self,
        query: str,
        k: int = 4,
        min_score: float = 0.25,
        doc_type: Optional[str] = None,
    ) -> List[RetrievedChunk]:
        """Return the top-k chunks for ``query`` (cosine relevance in ~[0,1])."""
        if not query.strip():
            raise RAGError("Query must not be empty.")
        flt = {"doc_type": doc_type} if doc_type else None
        try:
            results = self.store.similarity_search_with_relevance_scores(query, k=k, filter=flt)
        except Exception as exc:
            raise RAGError(f"Retrieval failed: {exc}") from exc

        return [
            RetrievedChunk(
                content=doc.page_content,
                source=doc.metadata.get("source", "unknown"),
                doc_type=doc.metadata.get("doc_type", "text"),
                section=doc.metadata.get("section", ""),
                score=round(float(score), 4),
            )
            for doc, score in results
            if score >= min_score
        ]

    # ------------------------------------------------------------------ misc
    def count(self) -> int:
        try:
            return self.store._collection.count()  # noqa: SLF001 (no public count API)
        except Exception:
            return 0
