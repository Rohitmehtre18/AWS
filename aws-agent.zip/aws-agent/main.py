"""
main.py
=======
FastAPI entry point for the AWS Cloud & Log Intelligence Agent.

Run locally:
    uvicorn main:app --reload --port 8000
Interactive docs:
    http://localhost:8000/docs
"""

from __future__ import annotations

import logging
import os
from contextlib import asynccontextmanager
from pathlib import Path
from typing import List, Optional

from dotenv import load_dotenv
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

load_dotenv()  # must run before modules read env vars

from log_analyzer import LogAnalyzer, TroubleshootingResponse  # noqa: E402
from rag_engine import SUPPORTED_EXTENSIONS, RAGEngine, RAGError  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
logger = logging.getLogger("main")

MAX_UPLOAD_BYTES = int(float(os.getenv("MAX_UPLOAD_MB", "2")) * 1024 * 1024)
TOP_K = int(os.getenv("TOP_K", "4"))

# Populated during lifespan startup
state: dict = {}


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Load the embedding model + vector store once; seed docs on first run."""
    engine = RAGEngine(
        persist_dir=os.getenv("CHROMA_DIR", "./chroma_db"),
        embedding_model=os.getenv("EMBEDDING_MODEL", "BAAI/bge-small-en-v1.5"),
    )
    if engine.count() == 0:
        seeded = engine.seed_from_dir(os.getenv("SEED_DOCS_DIR", "./data/sample_docs"))
        logger.info("Seeded knowledge base with %d chunks", seeded)
    state["engine"] = engine
    state["analyzer"] = LogAnalyzer()
    yield
    state.clear()


app = FastAPI(
    title="AWS Cloud & Log Intelligence Agent",
    version="1.0.0",
    description="RAG-powered troubleshooting for AWS errors, logs and architecture questions.",
    lifespan=lifespan,
)

origins = [o.strip() for o in os.getenv("CORS_ORIGINS", "*").split(",") if o.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials="*" not in origins,  # browsers reject credentials with wildcard origin
    allow_methods=["*"],
    allow_headers=["*"],
)


# ----------------------------------------------------------------------------
# Schemas
# ----------------------------------------------------------------------------
class QueryRequest(BaseModel):
    question: str = Field(..., min_length=3, max_length=4000,
                          examples=["Why does my Lambda get AccessDeniedException writing to S3?"])
    log_snippet: Optional[str] = Field(
        None, max_length=20000, description="Optional raw log lines or config (JSON/YAML) to analyze alongside the question."
    )
    top_k: int = Field(TOP_K, ge=1, le=10)


class IngestResult(BaseModel):
    ingested: List[dict]
    failed: List[dict]
    total_chunks_added: int
    collection_size: int


# ----------------------------------------------------------------------------
# Endpoints
# ----------------------------------------------------------------------------
@app.get("/health", tags=["meta"])
def health():
    engine: RAGEngine = state["engine"]
    analyzer: LogAnalyzer = state["analyzer"]
    return {
        "status": "ok",
        "chunks_indexed": engine.count(),
        "embedding_model": engine.embedding_model,
        "llm_mode": "llm" if analyzer.llm.available else "offline",
        "llm_model": analyzer.llm.model,
    }


@app.post("/query", response_model=TroubleshootingResponse, tags=["agent"])
def query(req: QueryRequest):
    """Retrieve relevant docs and return a structured troubleshooting response."""
    engine: RAGEngine = state["engine"]
    analyzer: LogAnalyzer = state["analyzer"]
    try:
        # Search with question + the head of the log so error codes influence retrieval
        search_text = req.question + ("\n" + req.log_snippet[:1000] if req.log_snippet else "")
        chunks = engine.retrieve(search_text, k=req.top_k)
        return analyzer.analyze(req.question, chunks, extra_text=req.log_snippet)
    except RAGError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    except Exception as exc:
        logger.exception("Unhandled error in /query")
        raise HTTPException(status_code=500, detail=f"Internal error: {exc}")


@app.post("/ingest", response_model=IngestResult, tags=["agent"])
def ingest(
    files: List[UploadFile] = File(default=[], description="Markdown docs, .log, .txt, .json, .yaml files"),
    text: Optional[str] = Form(None, description="Raw text/log to ingest instead of (or in addition to) files"),
    source_name: str = Form("pasted_text.txt", description="Label used for the raw text"),
):
    """Add documentation or error-log samples to the vector store at runtime."""
    engine: RAGEngine = state["engine"]
    if not files and not (text and text.strip()):
        raise HTTPException(status_code=400, detail="Provide at least one file or a 'text' field.")

    ingested, failed, total = [], [], 0

    for f in files:
        name = f.filename or "upload.txt"
        ext = Path(name).suffix.lower()
        if ext not in SUPPORTED_EXTENSIONS:
            failed.append({"source": name, "error": f"Unsupported type '{ext}'"})
            continue
        raw = f.file.read(MAX_UPLOAD_BYTES + 1)
        if len(raw) > MAX_UPLOAD_BYTES:
            failed.append({"source": name, "error": f"File exceeds {MAX_UPLOAD_BYTES // 1024 // 1024} MB limit"})
            continue
        try:
            n = engine.ingest_text(raw.decode("utf-8", errors="ignore"), name)
            ingested.append({"source": name, "chunks": n})
            total += n
        except RAGError as exc:
            failed.append({"source": name, "error": str(exc)})

    if text and text.strip():
        try:
            n = engine.ingest_text(text, source_name)
            ingested.append({"source": source_name, "chunks": n})
            total += n
        except RAGError as exc:
            failed.append({"source": source_name, "error": str(exc)})

    if not ingested:
        raise HTTPException(status_code=422, detail={"message": "Nothing ingested", "failed": failed})
    return IngestResult(ingested=ingested, failed=failed, total_chunks_added=total,
                        collection_size=engine.count())
