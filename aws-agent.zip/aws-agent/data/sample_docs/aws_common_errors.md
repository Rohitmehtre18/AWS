# AWS Common Errors Cheat Sheet

## IAM: AccessDenied / UnauthorizedOperation
An `AccessDenied` error means no policy allows the action, or an explicit Deny / SCP / permissions boundary blocks it.
Fix: check the identity policy, the resource policy (S3 bucket policy, KMS key policy), SCPs and permission boundaries.
Use `aws sts get-caller-identity` to confirm which principal is calling, and the IAM Policy Simulator to test.
Decode "encoded authorization failure" messages with `aws sts decode-authorization-message`.

## Lambda: Task timed out / Throttling
`Task timed out after N seconds` means the function exceeded its configured timeout.
Fix: raise the timeout (max 900s), increase memory (CPU scales with memory), check cold starts and slow downstream calls.
`TooManyRequestsException` / `Rate Exceeded` means concurrency limits were hit. Request a quota increase or set reserved concurrency.
For VPC-attached functions without a NAT gateway or VPC endpoints, outbound calls hang until the timeout.

## Lambda: Out of memory
`Runtime exited with error: signal: killed` and "Max Memory Used" equal to "Memory Size" indicate OOM. Increase memory size.

## S3: NoSuchBucket / 403 / SlowDown
`NoSuchBucket`: wrong name or region. `403 Forbidden` with correct IAM often means a bucket policy, Block Public Access, or KMS key permission issue.
`SlowDown` (503) means request rate is too high for a prefix. Spread keys across prefixes and add exponential backoff.

## EC2: InsufficientInstanceCapacity / InstanceLimitExceeded
`InsufficientInstanceCapacity`: AWS has no capacity for that type in the AZ. Retry later, try another AZ or instance type.
`InstanceLimitExceeded` / `VcpuLimitExceeded`: raise Service Quotas for the vCPU family.

## EC2: SSH connection timed out
Check security group inbound rule for port 22, NACLs, route table to an Internet Gateway, public IP / Elastic IP.
Never open port 22 to 0.0.0.0/0. Prefer SSM Session Manager.

## RDS: Connection timeouts and too many connections
Check security group on port 3306/5432, subnet group, and `PubliclyAccessible`. `Too many connections` means max_connections is exceeded.
Use RDS Proxy or a connection pool, and scale the instance class.

## DynamoDB: ProvisionedThroughputExceededException
Requests exceed provisioned capacity or a hot partition is being hit. Switch to on-demand mode, enable auto scaling,
redesign partition keys for even distribution, and use exponential backoff (SDKs do this by default).

## API Gateway: 502 / 504
502 usually means a malformed response from a Lambda proxy integration (must return statusCode, headers, body).
504 means the integration exceeded 29 seconds. Use async patterns (SQS, Step Functions) for long tasks.

## ECS/EKS: CannotPullContainerError
The task cannot pull its image. Check ECR permissions on the task execution role, NAT or VPC endpoints for ECR/S3,
and that the image tag exists.

## Cost Optimization Quick Wins
Right-size EC2 using Compute Optimizer, use Savings Plans, move infrequently accessed S3 data to Intelligent-Tiering,
delete unattached EBS volumes and idle NAT gateways, and use gateway VPC endpoints for S3/DynamoDB to avoid NAT data charges.

## Security Best Practices
Enforce least privilege (avoid `"Action": "*"` and `"Resource": "*"`), enable encryption at rest (KMS), enable S3 Block Public Access,
turn on CloudTrail and GuardDuty, and avoid `0.0.0.0/0` in security groups for admin ports.
